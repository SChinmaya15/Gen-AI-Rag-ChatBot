import time

def simulate_installation(req):
    time.sleep(1)
    print(f"Simulated installation of {req.application} ({req.version})")
