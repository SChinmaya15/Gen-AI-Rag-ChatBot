# Setup instructions are in the chat history
